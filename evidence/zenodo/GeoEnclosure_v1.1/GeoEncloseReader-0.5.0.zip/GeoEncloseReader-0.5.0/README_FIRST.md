# GeoEncloseReader 0.5.0

Audit tool of the GeoEnclosure method: it re-encloses interval-arithmetic covers with its own kernels, independent of the producer's, and checks the claimed signs. Research software; every output is DIAGNOSTIC_ONLY until a human decides otherwise. Full documentation (Japanese): `GER2/README.md`.

## Layout
- `GER2/geoenclosereader/`: the package.
  - `tri.py`, `tri2.py`: triaxial centre, pole and disk kernels (0.3.0).
  - `tri3.py`: general-point kernels, first order in the parameters (0.4.0).
  - `tri4.py`, `jet.py`: second order in the parameters (0.5.0).
  - `fiv.py`, `dual.py`: binary64 outward-rounded intervals and interval duals.
  - `kernels.py`, `verify.py`, `ledger.py`: Arb kernels and the ledger reader for the rotational family (0.1–0.2).
- `GER2/selftest_tri*.py`: self-tests.
- `v57/`: the non-interval reference quadrature (Gauss–Legendre) that the self-tests compare against.

## Requirements
- Python 3.11 or later, numpy, mpmath.
- `python-flint` only for `kernels.py` and `verify.py`.
- Tested with Python 3.11.18 and 3.13.18, numpy 2.4.6 and 2.5.3, and mpmath 1.4.1.

## Self-tests
```bash
cd GER2
python -I selftest_tri.py
python -I selftest_tri2.py
python -I selftest_tri3.py
python -I selftest_tri4.py
```
Each one ends with `FAILURES 0`.

## Known limits and corrections
See §7.3, §7.4 and §8 of `GER2/README.md`, including correction E3: in 0.4.0, a box whose centre lies outside the ball was expanded at that centre. This is fixed in 0.5.0.
