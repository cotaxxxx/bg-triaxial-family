# V63-A 実行手順（研究 PC、一回だけ）

**依頼：** この束を一度だけ流し、できた結果のファイルを一つ返してください。ファイルの中身は変えないでください。途中で止まったときも、`out/` をそのまま返してください。

**所要時間：** 最長で約 10 時間です（自己試験 約 2 分、bench 約 2 分、本番は 5 本を並べて 9 組、1 組最大 4 時間 40 分ほど）。

**メモリ：** 約 20 GB を使います。**ほかの重い計算は止めてから**流してください。

## 1. 準備

V60 の環境（`~/v60env`）をそのまま使えます。

## 2. 展開と実行

```bash
mkdir -p ~/v63a && cd ~/v63a
tar xzf /path/to/V63A_PC_BUNDLE.tar.gz
cd V63A_PC_BUNDLE
sha256sum -c MANIFEST.sha256          # すべて OK になることを確かめる
PY=~/v60env/bin/python nohup bash run_all.sh > run.out 2>&1 &
```

## 3. 返すもの

`V63A_PC_BUNDLE/V63A_RESULT_*.tar.gz` を一つ。途中で止まった場合は `tar czf V63A_PARTIAL.tar.gz out` で返してください。GitHub の `evidence/triaxial-chat` 枝の `evidence/chat/2026-11-22/D_TRI_V63A_GRID/results/` に置いてもらえれば、chat がそこから取ります。

## 4. してほしくないこと

ファイルの書き換え、並列数の変更、途中からの再開、結果の解釈（解釈は chat が行います）。
