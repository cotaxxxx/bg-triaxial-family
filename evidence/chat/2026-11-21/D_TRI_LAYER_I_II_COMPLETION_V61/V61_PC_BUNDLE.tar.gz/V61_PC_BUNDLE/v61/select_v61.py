"""V61 samples: the 39 V60 combos with status BUDGET (no combo added or dropped), ordered by V60 remaining boxes and
then V60 evals, largest first, so that idx % P spreads the heavy combos over the P processes."""
import json
R = [json.loads(l) for l in open('../v60res/out/res_v60.jsonl')]
B = [r for r in R if r['status'] == 'BUDGET']
assert len(B) == 39
B.sort(key=lambda r: (-r['remaining'], -r['evals'], json.dumps([r['layer'], r['stratum'], r['kind'], r['tile'], r['cell']])))
json.dump([{k: r[k] for k in ('layer', 'stratum', 'kind', 'tile', 'cell', 'box')} for r in B], open('samples_v61.json', 'w'), indent=0)
print(len(B), [(r['stratum'], r['kind'], r['tile'], r['remaining']) for r in B[:5]])
