# V61 実行手順（研究 PC、一回だけ）

**依頼：** この束を一度だけ流し、できた結果のファイルを一つ返してください。

- ファイルの中身は変えないでください。
- 途中で止まったときも、`out/` をそのまま返してください。

**所要時間：** 最長で約 14 時間です。
- 自己試験に約 2 分かかります。
- 本番は 16 本を並べて流し、1 本が最大 3 組を、1 組あたり最大 4 時間 40 分ほどかけて計算します。
- 早く終わる組が多ければ、そのぶん短くなります。

**メモリ：** 約 16 GB を使います。

## 1. 準備

V60 の環境（`~/v60env`）をそのまま使えます。新しく作る場合は、次のとおりです。

```bash
PYBASE=/home/daybreak/.pyenv/versions/3.11.16/bin/python3.11
$PYBASE -m venv ~/v60env
~/v60env/bin/pip install numpy mpmath
```

## 2. 展開と実行

```bash
mkdir -p ~/v61 && cd ~/v61
tar xzf /path/to/V61_PC_BUNDLE.tar.gz
cd V61_PC_BUNDLE
sha256sum -c MANIFEST.sha256          # すべて OK になることを確かめる
PY=~/v60env/bin/python bash run_all.sh
```

途中で止めないために、端末を閉じても動き続けるように起動してください（例：`PY=~/v60env/bin/python nohup bash run_all.sh > run.out 2>&1 &`、または `tmux` の中で起動する）。

## 3. 返すもの

`V61_PC_BUNDLE/V61_RESULT_*.tar.gz` を一つ返してください。

途中で止まった場合は、次のようにまとめて返してください。

```bash
tar czf V61_PARTIAL.tar.gz out
```

## 4. してほしくないこと

- ファイルの書き換え、並列数の変更、途中からの再開。
- 結果の解釈。解釈は chat が行います。
